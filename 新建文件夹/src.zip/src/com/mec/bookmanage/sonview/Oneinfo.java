package com.mec.bookmanage.sonview;

import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JLabel;

import com.mec.bookmanage.fatherview.IBKmanageView;
import com.mec.bookmanage.model.PlaceModel;

public class Oneinfo implements IBKmanageView{
	private JFrame jFrame;
	private Container container;
	private PlaceModel model;
	private JLabel jLabel1,jLabel2,jLabel3,jLabel4;
	
	public Oneinfo(PlaceModel pm) {
		this.model = pm;
		init();
		dealAction();
	}
	
	@Override
	public void init() {
		jFrame = new JFrame("查询车位信息");
		jFrame.setSize(800, 560);
		jFrame.setResizable(false);
		jFrame.setLocationRelativeTo(null);
		jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		container = jFrame.getContentPane();
		container.setLayout(null);
		
		jLabel1 = new JLabel("",JLabel.CENTER);
		jLabel1.setBounds(0, 0, 800, 130);
		jLabel1.setFont(warningTopicfont);
		jLabel1.setText("车位编号:   "+model.getNumber());
		container.add(jLabel1);
		
		jLabel2 = new JLabel("",JLabel.CENTER);
		jLabel2.setBounds(0, 140, 800, 130);
		jLabel2.setFont(warningTopicfont);
		jLabel2.setText("是否空闲:   "+model.getStatus());
		container.add(jLabel2);
		
		jLabel3 = new JLabel("",JLabel.CENTER);
		jLabel3.setBounds(0, 280, 800, 130);
		jLabel3.setFont(warningTopicfont);
		jLabel3.setText("收费/小时:   "+model.getMoney());
		container.add(jLabel3);
		
		jLabel4 = new JLabel("",JLabel.CENTER);
		jLabel4.setBounds(0, 420, 800, 130);
		jLabel4.setFont(warningTopicfont);
		jLabel4.setText("车位位置:   "+model.getLocation());
		container.add(jLabel4);
		
	}

	@Override
	public void dealAction() {	
	}

	@Override
	public void showView() {
		jFrame.setVisible(true);
	}

	@Override
	public void exitView() {
		
	}

}
