package com.mec.bookmanage.fatherview;

public class MainView {
	public static void main(String[] args) {
		new LoginView().showView();
	}
}
